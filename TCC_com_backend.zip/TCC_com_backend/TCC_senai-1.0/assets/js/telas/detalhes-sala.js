Object.assign(views, {

      /* ================= SALA ================= */

      room: () => {

        const r = S.sel.room;

        return pg(`

          ${back("rooms")}

          <div class="${CARD} p-5">

            ${r
            ? `

                  ${r.imagem
              ? `
                        <img
                          src="${esc(r.imagem)}"
                          alt="${esc(r.nome)}"
                          class="mb-4 h-64 w-full rounded-xl object-cover"
                        >
                      `
              : ""
            }

                  <div class="flex flex-wrap items-center justify-between gap-2">

                    <h2 class="text-xl font-bold text-[#A80D25]">
                      ${esc(r.nome)}
                    </h2>

                    ${badge(
              r.disponivel
                ? "Disponível"
                : "Ocupado"
            )}

                  </div>

                  <div class="my-4 grid gap-3 text-sm sm:grid-cols-3">

                    ${[
              [
                "users",
                "Capacidade",
                `${r.capacidade} pessoas`
              ],
              [
                "building-2",
                "Tipo",
                r.tipo
              ],
              [
                "map-pin",
                "Localização",
                `Bloco ${r.bloco} · ${r.piso}`
              ]
            ]
              .map(
                ([i, k, v]) => `
                          <div class="flex items-center gap-3">

                            <span class="text-[#C8102E]">
                              ${ic(i, "w-5 h-5")}
                            </span>

                            <div>

                              <p class="text-xs text-[#6B7280]">
                                ${k}
                              </p>

                              <p class="font-semibold">
                                ${esc(v)}
                              </p>

                            </div>

                          </div>
                        `
              )
              .join("")}

                  </div>

                  <h3 class="font-bold">
                    Descrição
                  </h3>

                  <p class="mb-4 text-sm text-[#6B7280]">
                    ${esc(r.descricao)}
                  </p>

                  <h3 class="mb-2 font-bold">
                    Equipamentos
                  </h3>

                  <div class="mb-5 flex flex-wrap gap-3">

                    ${(r.equipamentos || [])
              .map(
                (e) => `
                          <span class="flex items-center gap-2 rounded-xl border border-[#E5E7EB] px-3 py-2 text-sm">

                            <span class="text-[#C8102E]">
                              ${ic(
                  EQUIP[e] || "plug"
                )}
                            </span>

                            ${esc(e)}

                          </span>
                        `
              )
              .join("")}

                  </div>

                  ${btn(
                "Reservar este espaço",
                {
                  a: "reservarSala",
                  i: "plus"
                }
              )}

                `
            : empty(
              "building-2",
              "Nenhum espaço selecionado",
              "Selecione um espaço para visualizar seus detalhes."
            )
          }

          </div>
        `);
      },

});
