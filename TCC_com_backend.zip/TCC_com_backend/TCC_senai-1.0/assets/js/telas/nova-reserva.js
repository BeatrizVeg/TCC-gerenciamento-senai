Object.assign(views, {

     /* ================= NOVA RESERVA ================= */

new: () => {

  const b = S.ui.bloco;
  const sala = S.ui.sala;

  const salas = S.rooms.filter(
    r => r.bloco === b
  );

  return pg(`

    <form data-form="nova" class="space-y-6">

      <section class="${CARD} p-5">

        ${step(
          1,
          "Escolha o bloco"
        )}

        ${blockSelector(b)}

      </section>


      <section class="${CARD} p-5">

        ${step(
          2,
          "Escolha a sala"
        )}

        ${!b
          ? `
              <p class="text-sm text-[#6B7280]">
                Selecione um bloco para ver as salas.
              </p>
            `
          : salas.length
            ? `
                <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">

                  ${salas
                    .map(
                      r =>
                        roomCard(
                          r,
                          "sala",
                          sala &&
                          String(sala.id) === String(r.id)
                        )
                    )
                    .join("")}

                </div>
              `
            : empty(
                "building-2",
                "Nenhuma sala cadastrada neste bloco.",
                "As salas disponíveis serão exibidas aqui quando forem cadastradas."
              )
        }

      </section>


      <section class="${CARD} p-5">

        ${step(
          3,
          "Data, horário e detalhes"
        )}

        <div class="grid gap-4 sm:grid-cols-2">

          ${input(
            "Data",
            "data",
            {
              type: "date"
            }
          )}

          ${input(
            "Turma",
            "turma"
          )}

          ${input(
            "Horário inicial",
            "ini",
            {
              type: "time"
            }
          )}

          ${input(
            "Horário final",
            "fim",
            {
              type: "time"
            }
          )}

          ${input(
            "Finalidade",
            "fin"
          )}

          ${input(
            "Quantidade de pessoas",
            "pes",
            {
              type: "number",
              extra: 'min="1"'
            }
          )}

          ${cameraFoto()}

          <div class="sm:col-span-2">

            ${field(
              "Observações",
              `
                <textarea
                  data-k="obs"
                  rows="3"
                  class="${FLD}"
                >${esc(S.f.obs)}</textarea>
              `
            )}

          </div>

        </div>

      </section>


      ${msgHtml()}


      ${btn("Solicitar reserva", {
        type: "submit",
        i: "check",
        dis: !sala || !S.f.fotoProfessor
      })}


    </form>

  `);
},

});
