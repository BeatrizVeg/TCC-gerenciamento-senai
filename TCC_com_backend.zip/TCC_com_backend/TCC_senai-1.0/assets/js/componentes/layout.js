    /* ================================================================
       LAYOUT
       ================================================================ */

    const nav = (k, l, i) => {

      const paginaAtiva =
        {
          reservation: "reservations",
          room: "rooms",
          new: "reservations"
        }[S.page] || S.page;

      const ativo = paginaAtiva === k;

      return `
        <a
          href="${href(k)}"
          class="relative flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${ativo
          ? "bg-white text-[#C8102E] shadow-sm"
          : "text-white hover:bg-white/10"
        }"
        >

          ${ativo
          ? `<span class="absolute bottom-2 left-0 top-2 w-1 rounded-r bg-[#C8102E]"></span>`
          : ""
        }

          ${ic(i, "w-[18px] h-[18px]")}

          ${l}

        </a>
      `;
    };


    const modal = () =>
      S.ui.modal
        ? `
          <div
            class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
            data-a="modal"
            data-v="0"
          >

            <div class="${CARD} w-full max-w-md p-6">

              <h3 class="mb-2 font-bold">
                Cancelar esta reserva?
              </h3>

              <p class="text-sm text-[#6B7280]">
                Depois de cancelada, a reserva não poderá ser recuperada.
              </p>

              <div class="mt-5 flex justify-end gap-2">

                ${btn("Voltar", {
          a: "modal",
          v: "0",
          k: "ghost"
        })}

                ${btn("Cancelar reserva", {
          a: "cancelarReserva"
        })}

              </div>

            </div>

          </div>
        `
        : "";


    const layout = (c) => {

      const unread =
        S.notifications.filter(
          (n) => !n.lida
        ).length;

      return `
        <div class="min-h-screen">

          ${S.menu
          ? `
                <div
                  class="fixed inset-0 z-30 bg-black/40 lg:hidden"
                  data-a="menu"
                  data-v="0"
                ></div>
              `
          : ""
        }

          <aside
            class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-[#C8102E] p-4 transition-transform lg:translate-x-0 ${S.menu
          ? "translate-x-0"
          : "-translate-x-full"
        }"
          >

            <div class="mb-6 px-2">

              ${logo}

              <p class="mt-2 text-sm font-semibold text-white">
                Reserva de Espaços
              </p>

            </div>

            <nav class="flex-1 space-y-1">
              ${NAV.map((n) => nav(...n)).join("")}
            </nav>

            <div class="space-y-1 border-t border-white/30 pt-3">

              ${nav(
          "notifications",
          "Notificações",
          "bell"
        )}

              ${nav(
          "login",
          "Sair",
          "log-out"
        )}

            </div>

          </aside>


          <div class="lg:pl-64">

            <header class="flex items-center justify-between px-4 py-4 lg:px-8">

              <div class="flex items-center gap-3">

                <button
                  type="button"
                  class="lg:hidden"
                  data-a="menu"
                  data-v="1"
                  aria-label="Abrir menu"
                >
                  ${ic("menu", "w-6 h-6")}
                </button>

                <h1 class="text-xl font-bold">
                  ${TITULOS[S.page] || "SENAI"}
                </h1>

              </div>


              <div class="flex items-center gap-3">

                <button
                  type="button"
                  data-a="go"
                  data-v="notifications"
                  class="relative rounded-full p-2 text-[#C8102E] transition hover:bg-red-50"
                >

                  ${ic("bell", "w-5 h-5")}

                  ${unread
          ? `<span class="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-[#1E2A78]"></span>`
          : ""
        }

                </button>


                <button
                  type="button"
                  data-a="go"
                  data-v="profile"
                  class="flex items-center gap-2"
                >

                  ${avatar(S.user?.nome, 40, S.ui.fotoPerfil || S.user?.foto)}

                  <span class="hidden text-left text-sm sm:block">

                    <b class="block">
                      ${esc(S.user?.nome || "Usuário")}
                    </b>

                    <span class="text-xs text-[#6B7280]">
                      ${esc(S.user?.tipo || "Perfil")}
                    </span>

                  </span>

                </button>

              </div>

            </header>

            ${c}

          </div>

          ${modal()}

        </div>
      `;
    };


    const authShell = (left, body) => `
      <div class="grid min-h-screen lg:grid-cols-2">

        <div class="relative hidden flex-col overflow-hidden bg-[#C8102E] p-12 text-white lg:flex">
          <img src="${(IN_PAGES ? "../" : "") + "assets/imagens/senai-fachada.jpg"}" alt="" aria-hidden="true" class="absolute inset-0 h-full w-full object-cover">
          <div class="absolute inset-0 bg-gradient-to-b from-[#C8102E]/90 via-[#C8102E]/75 to-[#8F0B21]/95"></div>
          <div class="relative z-10 flex flex-1 flex-col justify-between">
            ${left}
          </div>
        </div>

        <div class="flex items-center justify-center p-6">

          <div class="${CARD} w-full max-w-md p-8">

            <img src="${(IN_PAGES ? "../" : "") + "assets/imagens/senai-logo.png"}" alt="SENAI · Reserva de Espaços" width="140" height="36" class="mb-5 h-auto w-32 rounded-md lg:hidden">

            ${body}

          </div>

        </div>

      </div>
    `;


    const perk = (i, t) => `
      <div class="flex max-w-[10rem] items-center gap-3">

        <span class="rounded-xl bg-white/20 p-3">
          ${ic(i, "w-[22px] h-[22px]")}
        </span>

        <span class="text-sm font-semibold">
          ${t}
        </span>

      </div>
    `;
