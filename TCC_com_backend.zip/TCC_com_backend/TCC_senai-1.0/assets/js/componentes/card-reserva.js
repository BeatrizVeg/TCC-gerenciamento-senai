    /* ================================================================
       CARD DE RESERVA
       ================================================================ */

    const resCard = (r) => {

      const d = new Date(r.data + "T00:00:00");

      return `
        <div class="${CARD} flex items-center gap-3 p-3 transition hover:shadow-md">

          <div class="w-16 shrink-0 rounded-xl bg-[#A80D25] py-2 text-center text-white">

            <p class="text-xl font-bold leading-none">
              ${d.getDate()}
            </p>

            <p class="text-xs">
              ${MESES[d.getMonth()]}
            </p>

            <p class="text-xs">
              ${d.getFullYear()}
            </p>

          </div>

          ${r.imagem
          ? `
                <img
                  src="${esc(r.imagem)}"
                  alt=""
                  class="hidden h-16 w-24 rounded-lg object-cover sm:block"
                >
              `
          : ""
        }

          ${r.fotoProfessor
          ? `
                <div class="hidden h-16 w-16 shrink-0 overflow-hidden rounded-full border-2 border-[#C8102E] sm:flex">
                  <img
                    src="${esc(r.fotoProfessor)}"
                    alt="Professor responsável"
                    class="h-full w-full object-cover"
                  >
                </div>
              `
          : ""
        }

          <div class="min-w-0 flex-1">

            <p class="truncate font-bold text-[#A80D25]">
              ${esc(r.espaco)}
            </p>

            <p class="text-xs text-[#6B7280]">
              Bloco ${esc(r.bloco)} ·
              Turma ${esc(r.turma || "--")} ·
              ${esc(r.inicio)}–${esc(r.fim)}
            </p>

            ${r.responsavel
          ? `
                  <p class="mt-1 text-xs font-semibold text-[#1E2A78]">
                    Professor: ${esc(r.responsavel)}
                  </p>
                `
          : ""
        }

          </div>

          <div class="flex flex-col items-end gap-2">

            ${badge(r.status)}

            ${btn("Ver detalhes", {
          a: "verReserva",
          v: r.id,
          i: "eye",
          k: "outline",
          c: "!px-3 !py-1.5 text-xs"
        })}

          </div>

        </div>
      `;
    };
