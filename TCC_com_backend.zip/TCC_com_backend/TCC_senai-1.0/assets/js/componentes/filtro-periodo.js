    /* ================================================================
       FILTRO DE PERÍODO
       ================================================================ */

    const noPeriodo = (r, p) => {

      if (!p) return true;

      const a = new Date(
        r.data + "T00:00:00"
      );

      const diferenca =
        (a.getFullYear() - now.getFullYear()) * 12 +
        a.getMonth() -
        now.getMonth();

      return diferenca === (
        p === "Este mês" ? 0 : 1
      );
    };
