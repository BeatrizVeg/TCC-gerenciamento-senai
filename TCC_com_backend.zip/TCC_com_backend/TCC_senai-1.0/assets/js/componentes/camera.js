    /* ================================================================
       CÂMERA
       ================================================================ */

    const cameraFoto = () => `
      <div class="sm:col-span-2 rounded-2xl border border-[#E5E7EB] bg-[#F8F9FA] p-4">

        <div class="mb-3 flex items-center gap-2">
          ${ic("scan-face", "w-5 h-5 text-[#C8102E]")}

          <div>
            <p class="font-bold text-[#A80D25]">
              Foto do professor
            </p>

            <p class="text-xs text-[#6B7280]">
              Tire uma foto do rosto para registrar quem realizou a reserva.
            </p>
          </div>
        </div>

        <div class="flex flex-col items-center gap-3">

          <video
            id="cameraVideo"
            autoplay
            playsinline
            class="hidden w-full max-w-sm rounded-xl bg-black object-cover"
          ></video>

          <canvas id="cameraCanvas" class="hidden"></canvas>

          <img
            id="fotoPreview"
            src="${esc(S.f.fotoProfessor || "")}"
            class="${S.f.fotoProfessor ? "" : "hidden"
      } w-full max-w-sm rounded-xl object-cover"
            alt="Foto do professor"
          >

          <div class="flex flex-wrap justify-center gap-2">

            ${btn("Abrir câmera", {
        a: "abrirCamera",
        i: "camera",
        k: "outline"
      })}

            ${btn("Tirar foto", {
        a: "tirarFoto",
        i: "camera",
        dis: true
      })}

            ${S.f.fotoProfessor
        ? btn("Refazer foto", {
          a: "refazerFoto",
          i: "refresh-cw",
          k: "ghost"
        })
        : ""
      }

          </div>

          <p
            id="cameraStatus"
            class="text-center text-xs text-[#6B7280]"
          >
            A foto é obrigatória para enviar a reserva.
          </p>

        </div>
      </div>
    `;
