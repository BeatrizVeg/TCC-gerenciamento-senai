/* ================================================================
   LOGIN ADMINISTRATIVO
   Não há credenciais, senha nem atalho de acesso no front-end.
   O envio chama adminApi.login(), que hoje não está integrado
   (veja admin_api.js) e, por isso, nunca abre o painel.
   ================================================================ */

(() => {
  const $ = (s) => document.querySelector(s);

  const msg = (t) => {
    const el = $("#admin-msg");
    el.textContent = t;
    el.classList.toggle("hidden", !t);
  };

  if (window.lucide) lucide.createIcons();

  $("#admin-pw").addEventListener("click", () => {
    const i = $("#admin-senha");
    i.type = i.type === "password" ? "text" : "password";
  });

  $("#form-admin").addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = $("#admin-email").value.trim();
    const senha = $("#admin-senha").value;

    if (!email || !senha) {
      msg("Informe o e-mail/usuário e a senha.");
      return;
    }

    msg("");
    $("#admin-entrar").disabled = true;

    try {
      await adminApi.login({ email, senha });
      window.location.href = "admin.html";
    } catch (err) {
      msg(
        err && err.code === "NAO_INTEGRADO"
          ? "O login administrativo ainda não está disponível."
          : "Não foi possível entrar. Verifique os dados e tente novamente."
      );
    } finally {
      $("#admin-entrar").disabled = false;
    }
  });
})();
