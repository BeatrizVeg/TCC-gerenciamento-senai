    /* ================================================================
       LOGIN
       ================================================================ */

    const login = () =>
      authShell(
        `
          <div>
            ${logo}

            <p class="mt-2 text-sm">
              Reserva de Espaços
            </p>
          </div>

          <div>

            <h1 class="text-4xl font-bold leading-tight">
              Bem-vindo ao sistema do SENAI
            </h1>

            <p class="mt-3 max-w-md text-white/85">
              Reserve salas e espaços de forma rápida e organizada para as suas atividades.
            </p>

          </div>

          <div class="flex gap-8">

            ${perk(
          "calendar-days",
          "Reserve salas e espaços"
        )}

            ${perk(
          "clock",
          "Acompanhe seus agendamentos"
        )}

          </div>
        `,
        `
          <h2 class="text-2xl font-bold text-[#C8102E]">
            Faça login para continuar
          </h2>

          <p class="mb-6 text-sm text-[#6B7280]">
            Acesse sua conta para gerenciar suas reservas e espaços.
          </p>

          <form data-form="login" class="space-y-4">

            ${input(
          "E-mail ou usuário",
          "email",
          {
            icon: "user",
            ph: "Digite seu e-mail",
            req: false
          }
        )}

            ${input(
          "Senha",
          "senha",
          {
            type: "password",
            icon: "lock",
            ph: "Digite sua senha",
            req: false
          }
        )}

            <div class="flex items-center justify-between text-sm">

              <label class="flex items-center gap-2">
                <input
                  type="checkbox"
                  class="accent-[#C8102E]"
                >
                Lembrar de mim
              </label>

              <button
                type="button"
                class="text-[#C8102E] hover:underline"
              >
                Esqueci minha senha
              </button>

            </div>

            ${btn("Entrar", {
          type: "submit",
          c: "w-full"
        })}

          </form>

          <p class="mt-6 text-center text-sm text-[#6B7280]">

            Ainda não tem uma conta?

            <button
              type="button"
              data-a="go"
              data-v="register"
              class="font-semibold text-[#C8102E] hover:underline"
            >
              Criar conta
            </button>

          </p>
        `
      );
