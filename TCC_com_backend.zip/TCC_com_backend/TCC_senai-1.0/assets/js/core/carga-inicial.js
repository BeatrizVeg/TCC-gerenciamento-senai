    /* ================================================================
       CARGA INICIAL
       ================================================================ */

    async function load() {

      try {

        const [
          user,
          rooms,
          reservations,
          requests,
          notifications
        ] = await Promise.all([
          api.perfil(),
          api.salas(),
          api.reservas(),
          api.solicitacoes(),
          api.notificacoes()
        ]);

        Object.assign(S, {
          user,
          rooms,
          reservations,
          requests,
          notifications
        });

      } catch (err) {

        console.error(
          "Falha ao carregar dados:",
          err
        );

      }

      const fileName =
        window.location.pathname.split("/").pop() || "index.html";

      const pageByFile = {
        "index.html": "login",
        "cadastro.html": "register",
        "home.html": "home",
        "minhas_reservas.html": "reservations",
        "detalhes_reserva.html": "reservation",
        "salas.html": "rooms",
        "detalhes_sala.html": "room",
        "nova_reserva.html": "new",
        "solicitacoes.html": "requests",
        "perfil.html": "profile",
        "notificacoes.html": "notifications"
      };

      S.page = pageByFile[fileName] || "home";

      const params = new URLSearchParams(window.location.search);

      if (params.has("id")) {
        const id = params.get("id");
        S.sel.reservation = find(S.reservations, id);
        S.sel.room = find(S.rooms, id);
      }

      if (params.has("sala")) {
        S.ui.sala = find(S.rooms, params.get("sala"));
        if (S.ui.sala) {
          S.ui.bloco = S.ui.sala.bloco;
        }
      }

      if (params.has("data")) {
        S.f.data = params.get("data");
      }

      render();
    }
