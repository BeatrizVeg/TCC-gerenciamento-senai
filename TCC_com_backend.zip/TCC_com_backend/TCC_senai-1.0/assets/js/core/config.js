    /* ================================================================
       BACK-END
       ================================================================ */

    const BASE = "";

    /* ================================================================
       ROTAS (um arquivo HTML por tela)
       index.html fica na raiz; as demais telas ficam em pages/
       ================================================================ */

    // true quando a página atual está dentro de /pages (script carregado via ../assets/...)
    const IN_PAGES = (
      (document.currentScript && document.currentScript.getAttribute("src")) || ""
    ).startsWith("../");

    const ROUTES = {
      login: "index.html",
      register: "cadastro.html",
      home: "home.html",
      reservations: "minhas_reservas.html",
      reservation: "detalhes_reserva.html",
      rooms: "salas.html",
      room: "detalhes_sala.html",
      new: "nova_reserva.html",
      requests: "solicitacoes.html",
      profile: "perfil.html",
      notifications: "notificacoes.html"
    };

    // Caminho correto de uma tela a partir da página atual
    const href = (p) => {
      if (p === "login") return IN_PAGES ? "../index.html" : "index.html";
      const file = ROUTES[p] || ROUTES.home;
      return (IN_PAGES ? "" : "pages/") + file;
    };

    /* Chamada genérica ao back-end Python (Flask).
       Devolve o JSON; em caso de erro lança Error com a mensagem do servidor. */
    const request = async (method, path, body) => {
      const res = await fetch(BASE + "/api" + path, {
        method,
        credentials: "include",
        headers: body ? { "Content-Type": "application/json" } : {},
        body: body ? JSON.stringify(body) : undefined
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const err = new Error(data.erro || "Erro ao falar com o servidor.");
        err.status = res.status;
        throw err;
      }
      return data;
    };

    // Leitura que não quebra a tela quando o usuário não está logado
    const safe = (p, fallback) => p.catch((e) => {
      if (e.status !== 401) console.error(e);
      return fallback;
    });

    const api = {
      // leituras (usadas na carga inicial)
      usuarios: () => safe(request("GET", "/usuarios"), []),
      perfil: () => safe(request("GET", "/perfil"), null),
      salas: () => safe(request("GET", "/salas"), []),
      reservas: () => safe(request("GET", "/reservas"), []),
      solicitacoes: () => safe(request("GET", "/solicitacoes"), []),
      notificacoes: () => safe(request("GET", "/notificacoes"), []),

      // escritas
      login: (email, senha) => request("POST", "/login", { email, senha }),
      logout: () => request("POST", "/logout"),
      cadastro: (dados) => request("POST", "/cadastro", dados),
      trocarSenha: (atual, nova) => request("PUT", "/senha", { atual, nova }),
      salvarPerfil: (dados) => request("PUT", "/perfil", dados),
      novaReserva: (dados) => request("POST", "/reservas", dados),
      cancelarReserva: (id) => request("PATCH", `/reservas/${id}/cancelar`),
      statusReserva: (id, status) => request("PATCH", `/reservas/${id}/status`, { status }),
      marcarLidas: () => request("PATCH", "/notificacoes/lidas")
    };
