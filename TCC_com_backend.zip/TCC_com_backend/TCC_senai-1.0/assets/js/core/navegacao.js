    /* ================================================================
       NAVEGAÇÃO
       ================================================================ */

    function go(p, o = {}) {
      const target = href(p);

      const params = new URLSearchParams();

      if (o.reservation?.id !== undefined) {
        params.set("id", o.reservation.id);
      }
      if (o.room?.id !== undefined) {
        params.set("id", o.room.id);
      }
      if (p === "new" && o.sala?.id !== undefined) {
        params.set("sala", o.sala.id);
      }
      if (p === "new" && o.data) {
        params.set("data", o.data);
      }

      const query = params.toString();
      window.location.href = target + (query ? "?" + query : "");
    }


    const find = (list, id) =>
      list.find(
        (x) =>
          String(x.id) ===
          String(id)
      );
