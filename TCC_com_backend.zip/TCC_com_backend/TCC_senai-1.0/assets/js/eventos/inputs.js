    /* ================================================================
       INPUTS
       ================================================================ */

    document.addEventListener(
      "input",
      (e) => {

        const k =
          e.target.dataset.k;

        if (!k) return;

        S.f[k] =
          e.target.value;

        if (
          e.target.dataset.r
        ) {
          render();
        }

      }
    );
