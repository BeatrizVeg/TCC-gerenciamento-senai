    /* ================================================================
       FOTO DE PERFIL (SELEÇÃO DE ARQUIVO)
       ================================================================ */

    document.addEventListener(
      "change",
      async (e) => {

        const inp = e.target.closest(
          "[data-foto-input]"
        );

        if (!inp) return;

        const file =
          inp.files && inp.files[0];

        if (!file) return;

        if (
          !file.type.startsWith("image/")
        ) {

          S.ui.fotoMsg = [
            "err",
            "Selecione um arquivo de imagem válido."
          ];

          render();
          return;
        }

        try {

          const dataUrl =
            await redimensionarImagem(
              file
            );

          S.ui.fotoPerfil = dataUrl;

          if (S.user) {
            S.user.foto = dataUrl;
          }

          S.ui.fotoMsg = [
            "ok",
            "Foto de perfil atualizada."
          ];

          render();

        } catch (err) {

          console.error(
            "Erro ao processar a foto de perfil:",
            err
          );

          S.ui.fotoMsg = [
            "err",
            "Não foi possível carregar a imagem selecionada."
          ];

          render();
        }

      }
    );
