/* ================================================================
   ADMIN · CAMADA DE INTEGRAÇÃO COM O BACK-END
   ----------------------------------------------------------------
   Fala com o servidor Python (Flask) em /api. O servidor valida a
   sessão e o papel de administrador em TODA rota /api/admin/*
   (401/403), então conhecer o endereço da página não dá acesso.

   Contrato dos dados (mesmo da área dos professores):

   SALA        { id, nome, bloco: "A"|"B"|"C", piso, capacidade, tipo,
                 equipamentos: [], descricao, disponivel, imagem? }
   RESERVA     { id, numero, salaId, espaco, bloco, piso, data: "AAAA-MM-DD",
                 inicio: "HH:MM", fim: "HH:MM", turma, finalidade, pessoas,
                 descricao, responsavel, fotoProfessor, criadaEm,
                 status: "Em análise"|"Aprovada"|"Recusada"|"Cancelada",
                 motivoRecusa?, motivoCancelamento? }
   USUARIO     { id, nome, cpf, email, nascimento, telefone, matricula,
                 cargo, foto?, ativo: true|false }
   NOTIFICACAO { id, tipo, titulo, mensagem, criadaEm, lida, reservaId? }
   HISTORICO   { id, tipo: "Aprovação"|"Recusa"|"Cancelamento"|"Alteração",
                 descricao, quando, autor }
   CONFIG      { dias: [0..6], abertura, fechamento, duracaoMaxHoras,
                 antecedenciaMinHoras, antecedenciaMaxDias }
   ================================================================ */

/* Chamada genérica ao back-end (mesmo padrão do core/config.js). */
const adminRequest = async (method, path, body) => {
  const res = await fetch("/api" + path, {
    method,
    credentials: "include",
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.erro || "Erro ao falar com o servidor.");
    err.status = res.status;
    throw err;
  }
  return data;
};

const adminApi = {

  /* ---------- autenticação ---------- */

  // POST /admin/login { email, senha } → dados do admin (cookie de sessão)
  login: async ({ email, senha }) =>
    adminRequest("POST", "/admin/login", { email, senha }),

  // GET /admin/sessao → { nome, papel: "admin" } ou null
  sessao: async () => {
    try {
      return await adminRequest("GET", "/admin/sessao");
    } catch {
      return null;
    }
  },

  // POST /admin/logout
  sair: async () => adminRequest("POST", "/admin/logout"),

  /* ---------- leitura inicial ---------- */

  // GET /salas
  salas: async () => adminRequest("GET", "/salas"),

  // GET /admin/reservas (todas as reservas de todos os professores)
  reservas: async () => adminRequest("GET", "/admin/reservas"),

  // GET /admin/usuarios
  usuarios: async () => adminRequest("GET", "/admin/usuarios"),

  // GET /admin/notificacoes
  notificacoes: async () => adminRequest("GET", "/admin/notificacoes"),

  // GET /admin/historico
  historico: async () => adminRequest("GET", "/admin/historico"),

  // GET /admin/configuracoes → CONFIG ou null
  config: async () => adminRequest("GET", "/admin/configuracoes"),

  /* ---------- escrita ---------- */

  // POST /salas
  criarSala: async (sala) => adminRequest("POST", "/salas", sala),

  // PUT /salas/:id
  editarSala: async (id, sala) => adminRequest("PUT", `/salas/${id}`, sala),

  // DELETE /salas/:id
  excluirSala: async (id) => adminRequest("DELETE", `/salas/${id}`),

  // PATCH /admin/reservas/:id/status { status: "Aprovada" }
  aprovarReserva: async (id) =>
    adminRequest("PATCH", `/admin/reservas/${id}/status`, { status: "Aprovada" }),

  // PATCH /admin/reservas/:id/status { status: "Recusada", motivoRecusa }
  recusarReserva: async (id, motivoRecusa) =>
    adminRequest("PATCH", `/admin/reservas/${id}/status`, { status: "Recusada", motivoRecusa }),

  // PATCH /admin/reservas/:id/status { status: "Cancelada", motivoCancelamento }
  cancelarReserva: async (id, motivoCancelamento) =>
    adminRequest("PATCH", `/admin/reservas/${id}/status`, { status: "Cancelada", motivoCancelamento }),

  // PUT /admin/usuarios/:id
  editarUsuario: async (id, dados) => adminRequest("PUT", `/admin/usuarios/${id}`, dados),

  // PATCH /admin/usuarios/:id { ativo }
  alterarAtivoUsuario: async (id, ativo) =>
    adminRequest("PATCH", `/admin/usuarios/${id}`, { ativo }),

  // PATCH /admin/notificacoes/:id { lida: true }  (id = null → todas)
  marcarNotificacaoLida: async (id) => {
    if (id === null || id === undefined) {
      return adminRequest("PATCH", "/notificacoes/lidas");
    }
    return adminRequest("PATCH", `/admin/notificacoes/${id}`, { lida: true });
  },

  // POST /admin/historico (o back-end também registra ações sozinho)
  registrarHistorico: async (entrada) =>
    adminRequest("POST", "/admin/historico", entrada),

  // PUT /admin/configuracoes
  salvarConfig: async (config) => adminRequest("PUT", "/admin/configuracoes", config)
};
