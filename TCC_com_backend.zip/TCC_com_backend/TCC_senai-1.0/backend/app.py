"""Back-end do sistema de reservas de salas do SENAI.

Servidor Flask que atende o site (páginas HTML em ../ e ../pages)
e expõe a API em /api. Banco de dados: MySQL (ver schema.sql).

Como rodar:
  pip install -r requirements.txt
  mysql -u root -p < schema.sql
  python criar_admin.py admin@senai.br senha123
  python app.py
"""
from functools import wraps

from flask import Flask, jsonify, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from db import consultar, executar

app = Flask(__name__, static_folder="..", static_url_path="")
app.secret_key = "troque-esta-chave-por-uma-secreta"  # TODO: usar variável de ambiente


# ---------------------------------------------------------------------------
# Ajuda
# ---------------------------------------------------------------------------

def erro(msg, codigo=400):
    return jsonify({"erro": msg}), codigo


def usuario_logado():
    uid = session.get("usuario_id")
    if not uid:
        return None
    return consultar("SELECT * FROM usuarios WHERE id = %s AND ativo = 1", (uid,), um=True)


def exige_login(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not usuario_logado():
            return erro("Não autenticado.", 401)
        return f(*a, **kw)
    return wrapper


def exige_admin(f):
    @wraps(f)
    def wrapper(*a, **kw):
        u = usuario_logado()
        if not u:
            return erro("Não autenticado.", 401)
        if u["perfil"] != "admin":
            return erro("Acesso restrito ao administrador.", 403)
        return f(*a, **kw)
    return wrapper


def fmt_hora(valor):
    """TIME do MySQL chega como timedelta; devolve 'HH:MM'."""
    if valor is None:
        return None
    total = int(valor.total_seconds()) if hasattr(valor, "total_seconds") else 0
    return f"{total // 3600:02d}:{(total % 3600) // 60:02d}"


def sala_json(s, equipamentos=None):
    return {
        "id": s["id"],
        "nome": s["nome"],
        "numero": s["numero"],
        "bloco": s["bloco"],
        "piso": s["piso"],
        "tipo": s["tipo"],
        "capacidade": s["capacidade"],
        "descricao": s["descricao"],
        "imagem": s["imagem"],
        "disponivel": bool(s["disponivel"]),
        "equipamentos": equipamentos if equipamentos is not None else [
            e["nome"] for e in consultar(
                "SELECT nome FROM sala_equipamentos WHERE sala_id = %s", (s["id"],))
        ],
    }


def reserva_json(r):
    return {
        "id": r["id"],
        "numero": r["id"],
        "salaId": r["sala_id"],
        "espaco": r["sala_nome"],
        "bloco": r["bloco"],
        "piso": r["piso"],
        "data": r["data"].isoformat() if r["data"] else None,
        "inicio": fmt_hora(r["inicio"]),
        "fim": fmt_hora(r["fim"]),
        "turma": r["turma"],
        "finalidade": r["finalidade"],
        "pessoas": r["pessoas"],
        "descricao": r["observacoes"],
        "responsavel": r["responsavel"],
        "fotoProfessor": r["foto_professor"],
        "status": r["status"],
        "motivoRecusa": r["motivo_recusa"],
        "motivoCancelamento": r["motivo_cancelamento"],
        "criadaEm": r["criada_em"].isoformat() if r["criada_em"] else None,
    }


def usuario_json(u):
    return {
        "id": u["id"],
        "nome": u["nome"],
        "email": u["email"],
        "cpf": u["cpf"],
        "nascimento": u["nascimento"].isoformat() if u["nascimento"] else None,
        "telefone": u["telefone"],
        "matricula": u["matricula"],
        "cargo": u["cargo"],
        "perfil": u["perfil"],
        "foto": u["foto"],
        "ativo": bool(u["ativo"]),
    }


SQL_RESERVAS = """
    SELECT r.*, s.nome AS sala_nome, s.bloco, s.piso, u.nome AS responsavel
    FROM reservas r
    JOIN salas s ON s.id = r.sala_id
    JOIN usuarios u ON u.id = r.usuario_id
"""


# ---------------------------------------------------------------------------
# Autenticação (professores e admin usam o mesmo login)
# ---------------------------------------------------------------------------

@app.post("/api/cadastro")
def cadastro():
    d = request.get_json(force=True)
    if not d.get("nome") or not d.get("email") or not d.get("senha"):
        return erro("Nome, e-mail e senha são obrigatórios.")
    if consultar("SELECT id FROM usuarios WHERE email = %s", (d["email"],), um=True):
        return erro("E-mail já cadastrado.", 409)
    uid = executar(
        """INSERT INTO usuarios (nome, email, cpf, nascimento, telefone, matricula, cargo, foto, senha_hash)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (d["nome"], d["email"], d.get("cpf"), d.get("nascimento"), d.get("telefone"),
         d.get("matricula"), d.get("cargo", "Professor"), d.get("foto"),
         generate_password_hash(d["senha"])),
    )
    session["usuario_id"] = uid
    return jsonify({"ok": True, "id": uid}), 201


@app.post("/api/login")
def login():
    d = request.get_json(force=True)
    u = consultar("SELECT * FROM usuarios WHERE email = %s AND ativo = 1", (d.get("email"),), um=True)
    if not u or not check_password_hash(u["senha_hash"], d.get("senha", "")):
        return erro("E-mail ou senha incorretos.", 401)
    session["usuario_id"] = u["id"]
    return jsonify(usuario_json(u))


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/perfil")
@exige_login
def perfil():
    return jsonify(usuario_json(usuario_logado()))


@app.put("/api/perfil")
@exige_login
def salvar_perfil():
    u = usuario_logado()
    d = request.get_json(force=True)
    executar(
        """UPDATE usuarios SET nome=%s, cpf=%s, nascimento=%s, telefone=%s,
           matricula=%s, cargo=%s, foto=COALESCE(%s, foto) WHERE id=%s""",
        (d.get("nome", u["nome"]), d.get("cpf", u["cpf"]), d.get("nascimento", u["nascimento"]),
         d.get("telefone", u["telefone"]), d.get("matricula", u["matricula"]),
         d.get("cargo", u["cargo"]), d.get("foto"), u["id"]),
    )
    return jsonify(usuario_json(usuario_logado()))


@app.put("/api/senha")
@exige_login
def trocar_senha():
    u = usuario_logado()
    d = request.get_json(force=True)
    if not check_password_hash(u["senha_hash"], d.get("atual", "")):
        return erro("Senha atual incorreta.", 403)
    executar("UPDATE usuarios SET senha_hash = %s WHERE id = %s",
             (generate_password_hash(d.get("nova", "")), u["id"]))
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Área dos professores
# ---------------------------------------------------------------------------

@app.get("/api/usuarios")
@exige_login
def usuarios():
    return jsonify([usuario_json(u) for u in consultar("SELECT * FROM usuarios ORDER BY nome")])


@app.get("/api/salas")
def salas():
    return jsonify([sala_json(s) for s in consultar("SELECT * FROM salas ORDER BY nome")])


@app.get("/api/reservas")
@exige_login
def minhas_reservas():
    u = usuario_logado()
    where = "" if u["perfil"] == "admin" else "WHERE r.usuario_id = %s"
    params = () if u["perfil"] == "admin" else (u["id"],)
    rows = consultar(SQL_RESERVAS + where + " ORDER BY r.data DESC, r.inicio DESC", params)
    return jsonify([reserva_json(r) for r in rows])


@app.get("/api/solicitacoes")
@exige_login
def solicitacoes():
    u = usuario_logado()
    where = "WHERE r.status = 'Em análise'" if u["perfil"] == "admin" \
        else "WHERE r.usuario_id = %s AND r.status = 'Em análise'"
    params = () if u["perfil"] == "admin" else (u["id"],)
    rows = consultar(SQL_RESERVAS + where + " ORDER BY r.data, r.inicio", params)
    return jsonify([reserva_json(r) for r in rows])


@app.post("/api/reservas")
@exige_login
def nova_reserva():
    u = usuario_logado()
    d = request.get_json(force=True)
    conflito = consultar(
        """SELECT id FROM reservas WHERE sala_id = %s AND data = %s
           AND status IN ('Em análise','Aprovada','Confirmada')
           AND inicio < %s AND fim > %s""",
        (d["salaId"], d["data"], d["fim"], d["inicio"]), um=True)
    if conflito:
        return erro("Já existe uma reserva nesse horário.", 409)
    rid = executar(
        """INSERT INTO reservas (usuario_id, sala_id, data, inicio, fim, turma,
           finalidade, pessoas, observacoes, foto_professor)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (u["id"], d["salaId"], d["data"], d["inicio"], d["fim"], d.get("turma"),
         d.get("finalidade"), d.get("pessoas"), d.get("descricao"),
         d.get("fotoProfessor") or u["foto"] or ""),
    )
    return jsonify({"ok": True, "id": rid}), 201


@app.patch("/api/reservas/<int:rid>/cancelar")
@exige_login
def cancelar_reserva(rid):
    u = usuario_logado()
    r = consultar("SELECT * FROM reservas WHERE id = %s", (rid,), um=True)
    if not r or (r["usuario_id"] != u["id"] and u["perfil"] != "admin"):
        return erro("Reserva não encontrada.", 404)
    executar("UPDATE reservas SET status = 'Cancelada' WHERE id = %s", (rid,))
    return jsonify({"ok": True})


@app.patch("/api/reservas/<int:rid>/status")
@exige_admin
def status_reserva(rid):
    d = request.get_json(force=True)
    return _mudar_status(rid, d.get("status"), d)


@app.get("/api/notificacoes")
@exige_login
def notificacoes():
    u = usuario_logado()
    rows = consultar(
        "SELECT * FROM notificacoes WHERE usuario_id = %s ORDER BY criada_em DESC", (u["id"],))
    return jsonify([{
        "id": n["id"], "tipo": n["categoria"], "titulo": n["titulo"],
        "mensagem": n["mensagem"], "lida": bool(n["lida"]),
        "criadaEm": n["criada_em"].isoformat() if n["criada_em"] else None,
    } for n in rows])


@app.patch("/api/notificacoes/lidas")
@exige_login
def marcar_lidas():
    executar("UPDATE notificacoes SET lida = 1 WHERE usuario_id = %s",
             (usuario_logado()["id"],))
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Área do administrador
# ---------------------------------------------------------------------------

@app.post("/api/admin/login")
def admin_login():
    d = request.get_json(force=True)
    u = consultar(
        "SELECT * FROM usuarios WHERE email = %s AND perfil = 'admin' AND ativo = 1",
        (d.get("email"),), um=True)
    if not u or not check_password_hash(u["senha_hash"], d.get("senha", "")):
        return erro("E-mail ou senha incorretos.", 401)
    session["usuario_id"] = u["id"]
    return jsonify(usuario_json(u))


@app.get("/api/admin/sessao")
def admin_sessao():
    u = usuario_logado()
    if not u or u["perfil"] != "admin":
        return jsonify(None)
    return jsonify({**usuario_json(u), "papel": "admin"})


@app.post("/api/admin/logout")
def admin_logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/admin/reservas")
@exige_admin
def admin_reservas():
    rows = consultar(SQL_RESERVAS + " ORDER BY r.data DESC, r.inicio DESC")
    return jsonify([reserva_json(r) for r in rows])


def _mudar_status(rid, status, d):
    permitidos = {"Aprovada": "Aprovação", "Recusada": "Recusa", "Cancelada": "Cancelamento"}
    if status not in permitidos:
        return erro("Status inválido.")
    executar(
        "UPDATE reservas SET status = %s, motivo_recusa = %s, motivo_cancelamento = %s WHERE id = %s",
        (status, d.get("motivoRecusa"), d.get("motivoCancelamento"), rid))
    r = consultar(SQL_RESERVAS + " WHERE r.id = %s", (rid,), um=True)
    if r:
        executar(
            "INSERT INTO notificacoes (usuario_id, titulo, mensagem, categoria) VALUES (%s,%s,%s,'reserva')",
            (r["usuario_id"], f"Reserva {status.lower()}",
             f"Sua reserva da sala {r['sala_nome']} em {r['data']} foi {status.lower()}."))
        executar(
            "INSERT INTO historico (tipo, descricao, autor) VALUES (%s,%s,%s)",
            (permitidos[status], f"Reserva #{rid} ({r['sala_nome']}) {status.lower()}.",
             usuario_logado()["nome"]))
    return jsonify({"ok": True})


@app.patch("/api/admin/reservas/<int:rid>/status")
@exige_admin
def admin_status_reserva(rid):
    d = request.get_json(force=True)
    return _mudar_status(rid, d.get("status"), d)


@app.get("/api/admin/usuarios")
@exige_admin
def admin_usuarios():
    return jsonify([usuario_json(u) for u in consultar("SELECT * FROM usuarios ORDER BY nome")])


@app.put("/api/admin/usuarios/<int:uid>")
@exige_admin
def admin_editar_usuario(uid):
    d = request.get_json(force=True)
    executar(
        """UPDATE usuarios SET nome=%s, cpf=%s, email=%s, nascimento=%s,
           telefone=%s, matricula=%s, cargo=%s WHERE id=%s""",
        (d.get("nome"), d.get("cpf"), d.get("email"), d.get("nascimento"),
         d.get("telefone"), d.get("matricula"), d.get("cargo"), uid))
    return jsonify({"ok": True})


@app.patch("/api/admin/usuarios/<int:uid>")
@exige_admin
def admin_ativo_usuario(uid):
    d = request.get_json(force=True)
    executar("UPDATE usuarios SET ativo = %s WHERE id = %s", (1 if d.get("ativo") else 0, uid))
    return jsonify({"ok": True})


@app.post("/api/salas")
@exige_admin
def criar_sala():
    d = request.get_json(force=True)
    sid = executar(
        """INSERT INTO salas (nome, numero, bloco, piso, tipo, capacidade, descricao, imagem, disponivel)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (d["nome"], d.get("numero"), d["bloco"], d.get("piso"), d.get("tipo", "Outros"),
         d.get("capacidade"), d.get("descricao"), d.get("imagem"),
         1 if d.get("disponivel", True) else 0))
    for eq in d.get("equipamentos", []):
        executar("INSERT INTO sala_equipamentos (sala_id, nome) VALUES (%s,%s)", (sid, eq))
    return jsonify({"ok": True, "id": sid}), 201


@app.put("/api/salas/<int:sid>")
@exige_admin
def editar_sala(sid):
    d = request.get_json(force=True)
    executar(
        """UPDATE salas SET nome=%s, numero=%s, bloco=%s, piso=%s, tipo=%s,
           capacidade=%s, descricao=%s, imagem=%s, disponivel=%s WHERE id=%s""",
        (d["nome"], d.get("numero"), d["bloco"], d.get("piso"), d.get("tipo", "Outros"),
         d.get("capacidade"), d.get("descricao"), d.get("imagem"),
         1 if d.get("disponivel", True) else 0, sid))
    if "equipamentos" in d:
        executar("DELETE FROM sala_equipamentos WHERE sala_id = %s", (sid,))
        for eq in d["equipamentos"]:
            executar("INSERT INTO sala_equipamentos (sala_id, nome) VALUES (%s,%s)", (sid, eq))
    return jsonify({"ok": True})


@app.delete("/api/salas/<int:sid>")
@exige_admin
def excluir_sala(sid):
    executar("DELETE FROM salas WHERE id = %s", (sid,))
    return jsonify({"ok": True})


@app.get("/api/admin/notificacoes")
@exige_admin
def admin_notificacoes():
    u = usuario_logado()
    rows = consultar(
        "SELECT * FROM notificacoes WHERE usuario_id = %s ORDER BY criada_em DESC", (u["id"],))
    return jsonify([{
        "id": n["id"], "tipo": n["categoria"], "titulo": n["titulo"],
        "mensagem": n["mensagem"], "lida": bool(n["lida"]),
        "criadaEm": n["criada_em"].isoformat() if n["criada_em"] else None,
    } for n in rows])


@app.patch("/api/admin/notificacoes/<int:nid>")
@exige_admin
def admin_notificacao_lida(nid):
    executar("UPDATE notificacoes SET lida = 1 WHERE id = %s AND usuario_id = %s",
             (nid, usuario_logado()["id"]))
    return jsonify({"ok": True})


@app.get("/api/admin/historico")
@exige_admin
def admin_historico():
    rows = consultar("SELECT * FROM historico ORDER BY criado_em DESC")
    return jsonify([{
        "id": h["id"], "tipo": h["tipo"], "descricao": h["descricao"],
        "autor": h["autor"],
        "quando": h["criado_em"].isoformat() if h["criado_em"] else None,
    } for h in rows])


@app.post("/api/admin/historico")
@exige_admin
def admin_registrar_historico():
    d = request.get_json(force=True)
    executar("INSERT INTO historico (tipo, descricao, autor) VALUES (%s,%s,%s)",
             (d.get("tipo", "Alteração"), d.get("descricao"), usuario_logado()["nome"]))
    return jsonify({"ok": True}), 201


@app.get("/api/admin/configuracoes")
@exige_admin
def admin_config():
    c = consultar("SELECT * FROM configuracoes WHERE id = 1", um=True)
    if not c:
        return jsonify(None)
    return jsonify({
        "dias": [int(x) for x in (c["dias"] or "").split(",") if x != ""],
        "abertura": fmt_hora(c["abertura"]),
        "fechamento": fmt_hora(c["fechamento"]),
        "duracaoMaxHoras": c["duracao_max_horas"],
        "antecedenciaMinHoras": c["antecedencia_min_horas"],
        "antecedenciaMaxDias": c["antecedencia_max_dias"],
    })


@app.put("/api/admin/configuracoes")
@exige_admin
def admin_salvar_config():
    d = request.get_json(force=True)
    executar(
        """UPDATE configuracoes SET dias=%s, abertura=%s, fechamento=%s,
           duracao_max_horas=%s, antecedencia_min_horas=%s, antecedencia_max_dias=%s
           WHERE id = 1""",
        (",".join(str(x) for x in d.get("dias", [])), d.get("abertura"), d.get("fechamento"),
         d.get("duracaoMaxHoras"), d.get("antecedenciaMinHoras"), d.get("antecedenciaMaxDias")))
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Páginas do site (serve os arquivos HTML)
# ---------------------------------------------------------------------------

@app.get("/")
def index():
    return app.send_static_file("index.html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
