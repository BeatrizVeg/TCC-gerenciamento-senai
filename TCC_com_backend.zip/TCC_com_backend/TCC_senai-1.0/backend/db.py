"""Conexão com o banco de dados MySQL.

Ajuste usuário e senha conforme o seu MySQL, ou use variáveis de ambiente:
  DB_HOST, DB_USER, DB_PASS, DB_NAME
"""
import os
import mysql.connector

CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "user": os.environ.get("DB_USER", "root"),
    "password": os.environ.get("DB_PASS", ""),
    "database": os.environ.get("DB_NAME", "senai_reservas"),
}


def conectar():
    return mysql.connector.connect(**CONFIG)


def consultar(sql, params=(), um=False):
    """SELECT: devolve lista de dicionários (ou um só, se um=True)."""
    conn = conectar()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params)
        return cur.fetchone() if um else cur.fetchall()
    finally:
        conn.close()


def executar(sql, params=()):
    """INSERT/UPDATE/DELETE: devolve o id da linha inserida (ou None)."""
    conn = conectar()
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()
